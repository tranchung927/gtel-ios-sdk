//
//  GTelSDK.h
//  GTelSDK
//
//  Created by ChungTV on 31/12/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for GTelSDK.
FOUNDATION_EXPORT double GTelSDKVersionNumber;

//! Project version string for GTelSDK.
FOUNDATION_EXPORT const unsigned char GTelSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GTelSDK/PublicHeader.h>


